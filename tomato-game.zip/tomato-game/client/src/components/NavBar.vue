<template>
  <div>
    <nav class="bg-pink-700 sticky top-0">
      <div class="container mx-auto p-4">
        <nav class="flex justify-between items-center">
          <div class="text-white text-2xl font-serif">
            Hello {{ user?.email?.split("@")[0] }}
          </div>
          <button
            class="p-2 rounded-md text-white border border-2 border-white-500"
            @click="logout"
          >
            Logout
          </button>
        </nav>
      </div>
    </nav>
  </div>
</template>

<script setup>
import { ref, onMounted } from "vue";
import { useRouter } from "vue-router";
const user = ref("");
const router = useRouter();
const logout = () => {
  localStorage.removeItem("user");
  router.push("/");
};
onMounted(() => {
  user.value = JSON.parse(localStorage.getItem("user"));
});
</script>

<style>
/* Add your custom styles here */
</style>
