<template>
  <div>
    <NavBar />
    <div class="text-center mt-10 text-2xl">Game over</div>
    <div
      class="mx-auto mt-10 mb-6 high-scores-container h-[205px] w-[400px] overflow-y-auto border border-pink-700 rounded"
    >
      <div
        class="high-scores-row flex justify-between p-2 border-pink-700"
        :class="{ 'border-b': index < scores.length - 1 }"
        v-for="(score, index) in scores"
        :key="index"
      >
        <div class="font-semibold">{{ score.email }}</div>
        <div class="text-right">{{ score.scores }}</div>
      </div>
    </div>
    <div class="flex justify-center items-center">
      <button
        @click="startNewGame"
        class="mt-4 bg-pink-700 text-white font-bold py-2 px-4 rounded hover:bg-green-600"
      >
        Start new game
      </button>
    </div>
  </div>
</template>

<script setup>
import NavBar from "./NavBar.vue";
import { ref, onMounted } from "vue";
const scores = ref([]);

const startNewGame = () => {
  window.location.reload();
};
const getScores = async () => {
  try {
    const response = await fetch("http://localhost:3000/getScores");
    const responseData = await response.json();
    scores.value = responseData;
  } catch (error) {
    console.log("error while fetching scores", error);
  }
};
onMounted(() => {
  getScores();
});
</script>

<style></style>
