
<template>
  <h1 class="text-2px font-semibold flex justify-center h-full text-pink-700">
    Welcome back, login for more fun!
  </h1>
  <div class="min-h-screen flex">
    <div
      class="w-1/2 bg-cover"
      :style="{ backgroundImage: 'url(' + backgroundImage + ')' }"
    ></div>
    <div class="w-1/2 flex items-center justify-center">
      <div
        class="bg-white border border-pink-700 p-8 rounded shadow-md w-full max-w-md"
      >
        <h1 class="text-2xl font-semibold mb-4">Login</h1>
        <form @submit.prevent="login">
          <div class="mb-4">
            <label for="email" class="block text-gray-700 text-sm font-bold"
              >Email:</label
            >
            <input
              type="email"
              id="email"
              v-model="email"
              class="w-full p-2 border rounded border-pink-700"
            />
          </div>
          <div class="mb-4">
            <label for="password" class="block text-gray-700 text-sm font-bold"
              >Password:</label
            >
            <input
              type="password"
              id="password"
              v-model="password"
              class="w-full p-2 border rounded border-pink-700"
            />
          </div>
          <button
            type="submit"
            class="bg-pink-700 text-white font-bold py-2 px-4 rounded hover:bg-blue-600"
          >
            Login
          </button>
        </form>
        <p class="mt-4">
          Don't have an account?
          <router-link to="/signup" class="text-pink-700 hover:underline"
            >Sign up</router-link
          >
        </p>
        <p id="message" :style="{ color: messageColor }">{{ loginMessage }}</p>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref } from "vue";
import { useRouter } from "vue-router";
import backgroundImage from "../assets/tomato-face.png";

const email = ref("");
const password = ref("");
const loginMessage = ref(""); // Message to display to the user
const messageColor = ref(""); // Color for the message text
const router = useRouter();
const user = ref("");

const login = async () => {
  try {
    const response = await fetch("http://localhost:3000/login", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ email: email.value, password: password.value }),
    });

    const responseData = await response.json();

    if (responseData.message === "Login successful") {
      // Login successful
      user.value = responseData.user;
      localStorage.setItem("user", JSON.stringify(responseData.user));
      loginMessage.value = "Login successful";
      messageColor.value = "green";
      // Redirect to the home page or perform any other desired action
      router.push("/home");
    } else if (responseData.message === "Invalid credentials") {
      // Invalid credentials
      loginMessage.value = "Invalid credentials";
      messageColor.value = "red";
    } else {
      // Handle other response messages as needed
      loginMessage.value = "An error occurred";
      messageColor.value = "red";
    }
  } catch (error) {
    console.error("Error:", error);
    loginMessage.value = "An error occurred";
    messageColor.value = "red";
  }
};
</script>
