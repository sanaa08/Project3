<template>
  <div v-if="isGameOver"><GameOver /></div>
  <div v-else class="min-h-screen bg-cover bg-center">
    <NavBar />
    <div class="container mx-auto mt-8"></div>

    <div class="flex flex-col items-center justify-center mt-n20">
      <div class="mb-4 max-w-md">
        <img
          :src="question"
          alt="Tomato"
          class="mb-4 max-w-md border border-pink-700 rounded"
        />
      </div>
      <div class="mb-5 border border-pink-700 rounded">Score: {{ score }}</div>
      <div class="text-4xl mb-8 -mt-3 border border-pink-700 rounded">
        Time Left: {{ timeLeft }}
      </div>
      <div class="flex space-x-4">
        <button
          v-for="number in numbers"
          :key="number"
          @click="tryNumber(number)"
          class="bg-pink-700 text-white font-bold py-2 px-4 rounded hover:bg-green-600"
        >
          {{ number }}
        </button>
      </div>
    </div>
    <div class="flex flex-col items-center justify-center">
      <input
        type="text"
        v-model="chosenNumber"
        readonly
        class="w-10 text-center bg-pink-700 px-4 rounded mt-5 text-white"
      />
      <button
        @click="checkSolution"
        class="mt-4 bg-pink-700 text-white font-bold py-2 px-4 rounded hover:bg-green-600"
      >
        Check Solution
      </button>
      <p v-if="message" :class="messageClass">{{ message }}</p>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted } from "vue";
import { useRouter } from "vue-router";
import GameOver from "../components/GameOver.vue";
import NavBar from "../components/NavBar.vue";

const question = ref("");
const numbers = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]; // Buttons from 0 to 9
const solution = ref(1);
const chosenNumber = ref(null);
const message = ref("");
const messageClass = ref("");
let timeoutId = null;
const user = ref("");
const timeLeft = ref(30); // Initial time of 30 seconds
let timer = null;
const isGameOver = ref(false);
const score = ref(0);

const incrementScore = () => {
  score.value++;
};

const startTimer = () => {
  timeLeft.value = 30; // Reset the timer to 30 seconds
  timer = setInterval(() => {
    timeLeft.value--; // Decrement the time by 1 second
    if (timeLeft.value === 0) {
      clearInterval(timer); // Clear the timer when time is up
      gameover();
    }
  }, 1000); // Execute every 1000ms (1 second)
};

const gameover = () => {
  message.value = "Game over";
  messageClass.value = "text-red-500";
  chosenNumber.value = null;
  isGameOver.value = true;

  saveScore();

  // Reset the timer and fetch a new question
  clearInterval(timer);
};

const fetchQuestion = async () => {
  clearInterval(timer); // Clear any existing timers
  try {
    const response = await fetch("https://marcconrad.com/uob/tomato/api.php");
    const data = await response.json();
    question.value = data.question;
    solution.value = data.solution;

    // Start a new timer
    startTimer();
  } catch (error) {
    console.error("Error fetching API data:", error);
  }
};

const tryNumber = (number) => {
  chosenNumber.value = number;
};

const checkSolution = () => {
  if (chosenNumber.value === solution.value) {
    message.value = "Correct answer!";
    messageClass.value = "text-green-500";
    incrementScore();
    chosenNumber.value = null; // Clear chosenNumber
    setTimeout(() => {
      message.value = "Fetching a new question...";
      fetchQuestion();
      setTimeout(() => {
        message.value = "";
      }, 1000); // Clear message after 1 second
    }, 2000); // Show "Correct answer" for 2 seconds
  } else {
    gameover();
  }
};

const saveScore = async () => {
  try {
    await fetch("http://localhost:3000/saveScore", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ email: user.value.email, score: score.value }),
    });
  } catch (error) {
    message.value = error.message;
  }
};

onMounted(() => {
  user.value = JSON.parse(localStorage.getItem("user"));
  fetchQuestion();
});
</script>

<style>
/* Add your custom styles here */
</style>
