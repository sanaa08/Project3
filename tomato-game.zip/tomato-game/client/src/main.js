import { createApp } from "vue";
import { createRouter, createWebHistory } from "vue-router";
import "./style.css";
import App from "./App.vue";
import Login from "./pages/Login.vue";
import Signup from "./pages/Signup.vue";
import Home from "./pages/Home.vue";

const routes = [
  { path: "/login", name: "login", component: Login },
  { path: "/signup", name: "signup", component: Signup },
  { path: "/", redirect: "/login" },
  { path: "/home", name: "home", component: Home, meta: { requiresAuth: true } },
];

const router = createRouter({
  history: createWebHistory(),
  routes,
});


router.beforeEach((to, from, next) => {
  if (to.matched.some((record) => record.meta.requiresAuth)) {
    // Check if the route requires authentication
    if (localStorage.getItem("user")) {
      // If "user" exists in localStorage, allow access to the route
      next();
    } else {
      // Redirect to the login page if "user" does not exist
      next({ name: "login" });
    }
  } else if (
    (to.path === "/login" && localStorage.getItem("user")) ||
    (to.path === "/signup" && localStorage.getItem("user"))
  ) {
    // If "user" exists in localStorage and the user is trying to access the "login" or "signup" pages, redirect to "/home"
    next({ name: "home" });
  } else {
    // For other routes that do not require authentication, proceed normally
    next();
  }
});


createApp(App).use(router).mount("#app");
