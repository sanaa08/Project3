<script setup></script>

<template>
  <div>
    <RouterView />
  </div>
</template>
