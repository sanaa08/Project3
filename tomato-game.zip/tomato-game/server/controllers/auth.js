const db = require("../dbconnection/dbconn");

const signUp = (req, res) => {
  const { email, password } = req.body;

  // Check if the email already exists in the database
  db.query("SELECT * FROM users WHERE email = ?", email, (err, results) => {
    if (err) {
      return res.status(500).json({ message: "Database error" });
    }

    if (results.length > 0) {
      return res.status(200).json({ message: "Email already in use" });
    }

    // If email is unique, insert the new user
    db.query(
      "INSERT INTO users (email, password) VALUES (?, ?)",
      [email, password],
      (err, results) => {
        if (err) {
          return res.status(500).json({ message: "Database error" });
        }
        const user = {
          id: results.insertId,
          email: email,
        };
        return res.status(201).json({ message: "User registered", user });
      }
    );
  });
};

const login = (req, res) => {
  const { email, password } = req.body;

  // Query the database to find the user by email and password
  db.query(
    "SELECT * FROM users WHERE email = ? AND password = ?",
    [email, password],
    (err, results) => {
      if (err) {
        return res.status(500).json({ message: "Database error" });
      }

      if (results.length === 0) {
        // User not found or invalid credentials
        return res.status(200).json({ message: "Invalid credentials" });
      }

      // User successfully authenticated
      const user = {
        id: results[0].id,
        email: results[0].email,
      };
      // You may want to create a user session/token here for future requests
      // For example, you can use JWT (JSON Web Tokens)

      return res.status(200).json({ message: "Login successful", user });
    }
  );
};

module.exports = { signUp, login };
