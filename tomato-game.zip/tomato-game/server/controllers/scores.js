const db = require("../dbconnection/dbconn");

const saveScore = (req, res) => {
  const { email, score } = req.body;
  db.query("SELECT * FROM scores WHERE email = ?", email, (err, results) => {
    if (err) {
      return res.status(500).json({ message: "Database error" });
    }

    // if user exists
    if (results.length > 0) {
      // if database score is bigger or equal to the incoming score - do nothing
      if (results[0].scores >= score) {
        return res.status(200);
      } else {
        // if the incoming score is bigger than the database score - update the database with the new score
        db.query(
          "UPDATE scores SET scores = ? WHERE id = ?",
          [score, results[0].id],
          (err, updateResults) => {
            if (err) {
              return res.status(500).json({ message: "Database error" });
            }
            return res.status(200).json({ message: "Score updated" });
          }
        );
      }
      // if user doesn't exist
    } else {
      // insert a new user with his score
      db.query(
        "INSERT INTO scores (email, scores) VALUES (?, ?)",
        [email, score],
        (err, results) => {
          if (err) {
            return res.status(500).json({
              message: "error inserting a new user into scores table",
            });
          }
          return res.status(200);
        }
      );
    }
  });
};

const getScores = (req, res) => {
  db.query(
    "SELECT email, scores FROM scores ORDER BY scores DESC LIMIT 5",
    (err, results) => {
      if (err) {
        // Handle database error
        return res.status(500).json({
          message: "error in fetching all scores",
        });
      } else {
        // Send the results to the client
        return res.status(200).json(results);
      }
    }
  );
};

module.exports = { saveScore, getScores };
