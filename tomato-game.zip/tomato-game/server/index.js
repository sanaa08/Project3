const express = require("express");
const cors = require("cors");
const authRoutes = require("./routes/auth");
const scoresRoutes = require("./routes/scores");

const app = express();
const port = 3000;

app.use(express.json());
app.use(cors());

app.use(authRoutes);
app.use(scoresRoutes);

app.listen(port, () => {
  console.log(`Server is running on port ${port}`);
});
